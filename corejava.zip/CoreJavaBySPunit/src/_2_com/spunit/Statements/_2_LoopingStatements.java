package _2_com.spunit.Statements;

public class _2_LoopingStatements {

	public static void main(String[] args) {

		ForLoop f = new ForLoop();
		f.dwl();
		f.fl();
	}
}

class DoWhileLoop{
	public void dwl(){
		int k = 1;
		do{
			System.out.println("Done");
			k++;
		}while(k<=5);
	}
}

class ForLoop extends DoWhileLoop{
	public void fl(){
		for(int i=0; i<=4;i++){
			System.out.println(i);
		}
	}
}

