package _2_com.spunit.Statements;

public class _1_ConditionalStatements {

	public static void main(String []args){
		
		SwitchStatement s = new SwitchStatement();
		s.is();
		s.ies();
		s.ss();
	}
}

class IfStatement{
	public void is(){
		int i =1;
		if(i==1){
			System.out.println("True");
		}
	}
}

class IfElseStatement extends IfStatement{
	public void ies(){
		int i =2;
		if(i==1){
			System.out.println("False");
		}else{
			System.out.println("True");
		}
	}
}

class SwitchStatement extends IfElseStatement{
	public void ss(){
		int i =2;
		switch(i){
			case 1 : System.out.println("1"); break;
			case 2 : System.out.println("2"); break;
			case 3 : System.out.println("3"); break;
			case 4 : System.out.println("4"); break;
			default : System.out.println("Not");
		}
	}
}


