package _5_com.spunit.Arrays;

public class Array {

	public static void main(String[] args) {
		/*
		 * Array is a collection of elements like int, string etc & having fixed
		 * size There are following types of array's 1. Single Dimensional 2.
		 * MultiDimensional
		 */

		SingleDimensional sd = new SingleDimensional();
		sd.show();
		
		MultiDimensional md = new MultiDimensional();
		md.display();
		
		JaggedArray ja = new JaggedArray();
		ja.run();
	}
}

class SingleDimensional {
	public void show() {
		int a[] = { 1, 2, 3, 4 };
		/* Reassign the value */
		a[0] = 9;
		for (int i : a) {
			System.out.println(i);
		}
	}
}

class MultiDimensional {
	public void display() {
		int arr[][]={{1,2,3},{2,4,5},{4,4,5}};
		/* Reassign the value */
		arr[0][0] = 9;
		for(int i=0;i<3;i++){  
			 for(int j=0;j<3;j++){  
			   System.out.print(arr[i][j]+" ");  
			 }  
			 System.out.println();  
			}  
	}
}

class JaggedArray{
	public void run(){
		int array[][]={{1,2,3},{2,4},{4,4,5,6}};
		int count = 0;  
        for (int i=0; i<array.length; i++)  
            for(int j=0; j<array[i].length; j++)  
                array[i][j] = count++;  
   
        //printing the data of a jagged array   
        for (int i=0; i<array.length; i++){  
            for (int j=0; j<array[i].length; j++){  
                System.out.print(array[i][j]+" ");  
            }  
            System.out.println();//new line  
        }  
	}
}