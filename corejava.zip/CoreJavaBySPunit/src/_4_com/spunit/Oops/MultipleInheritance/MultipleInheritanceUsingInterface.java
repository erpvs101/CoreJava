package _4_com.spunit.Oops.MultipleInheritance;

public class MultipleInheritanceUsingInterface {

public static void main(String[] args) {
		
		Sub obj = new Sub();
		obj.show();
		obj.run();	
	}
}

interface a{
	void show();
}
interface b{
	void run();
}
class Sub implements a,b{

	@Override
	public void run() {
		System.out.println("Method of b");
	}

	@Override
	public void show() {
		System.out.println("Method of a");
	}	
}
