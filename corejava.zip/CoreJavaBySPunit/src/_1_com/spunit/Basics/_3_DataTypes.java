package _1_com.spunit.Basics;

public class _3_DataTypes {

	public static void main(String[] args) {
		/*There are two types of DT in java
		 * 1. Primitive DT						: Having fixed size
		 * 2. Non-Primitive OR Reference DT		: Having no fixed size
		 * */ 		
		ReferenceDT rd = new ReferenceDT();
		rd.show();
		rd.display();		
	}
}

class PrimitiveDT{
	
	boolean b = true;						//true or false 1 bit
	byte bt = 100;							// 1 byte
	short sh = 10000;						// 2 byte
	int in = 1000000;						// 4 byte
	Long lo = 1_000_000_000_000_000_000l;	// 8 byte
	Float fl = 100.10f;						// 4 byte
	Double du = 100.1000d;					// 8 byte
	char ch = 'P';							// 2 byte   default value is Unicode '\u0000'
	
	String newLine = System.getProperty("line.separator");
	
	public void show(){
		System.out.println("Primitive DataType :" + newLine +
						   "---------------------------------------------------"+newLine +
						   "Boolen "+ b  + newLine +
						   "Byte   "+ bt + newLine +
						   "Short  "+ sh + newLine + 
						   "Int    "+ in + newLine +
						   "Long   "+ lo + newLine +
						   "Float  "+ fl + newLine + 
				           "Double "+ du + newLine + 
				           "Char   "+ ch + newLine +
				           "---------------------------------------------------");
	}
}
 
class ReferenceDT extends PrimitiveDT{
	String st = "PUNIT";
	int num[] = {1,2,3,4,5,6};
	public void display(){
		
		System.out.println("Reference DataType :" + newLine +
				   "---------------------------------------------------"+newLine +
				   "String         " + st + newLine +
				   "Integer Array  ");
		for(int i=0;i<5;i++){
			System.out.println(num[i]);
		}
		System.out.println("---------------------------------------------------");
	}
}