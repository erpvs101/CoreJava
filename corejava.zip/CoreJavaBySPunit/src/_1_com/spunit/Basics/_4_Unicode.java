package _1_com.spunit.Basics;

public class _4_Unicode {

	public static void main(String[] args) {
		/* Unicode Universal International Standard Character Encoding
		 * capable of representing most of world's written languages 
		 *  lowest value:\u0000
		 *  highest value:\uFFFF
		 * */ 
		
		String newLine = System.getProperty("line.separator");
		
		System.out.println("Unicode System :" + newLine + 
						   "-----------------------------------------------"+newLine+
						   "Lowest Value  :"+'\u0000' + newLine+
						   "Highest Value :"+'\uFFFF' + newLine+
						   "-----------------------------------------------");

	}

}