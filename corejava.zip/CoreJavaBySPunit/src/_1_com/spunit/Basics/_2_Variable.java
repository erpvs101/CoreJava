package _1_com.spunit.Basics;

public class _2_Variable {

	public static void main(String[] args) {
		/* There are three types of variable in the java
		 * 1. Instance	: scope inside the class but outside the method body 
		 * 2. Static	: scope inside the class but outside the method body
		 * 3. Local		: scope inside the method only
		 * */
		
		TypesOfVariable v = new TypesOfVariable();
		v.show();
	}
}

class TypesOfVariable{
	int a = 10;					//Instance
	static int b = 20;			//Static 
	public void show(){
		int c = 30;				//Local
		System.out.println("Instance Variable ="+ a+": "
					     + "Static Variable ="+ b+": "
					     + "Local Variable ="+ c);
	}
}
