package _1_com.spunit.Basics;

public class _5_Operators {

	public static void main(String[] args) {
		/* There are following types operators available in java
		 * 1. Unary Operator		: pre or post increment decrement
		 * 2. Arithmetic Operator	: +, -, *, / , %
		 * 3. Shift Operator		: <<, >>, >>>
		 * 4. Relational Operator	: <, >, <=, >=, ==, !=
		 * 5. Bitwise Operator		: &, ^(exclusive or), |,  
		 * 6. Logical Operator		: &&, ||
		 * 7. Ternary Operator		: ?:
		 * 8. Assignment Operator	: =, +=, -=, *=, /=, %=, ^=, |=, <<=, >>=, >>>=
		 * */

		TernaryOperator to = new TernaryOperator();
		to.uo();
		to.ao();
		to.so();
		to.ro();
		to.lo();
		to.to();
		
	}
}

class UnaryOperator{
	String newLine = System.getProperty("line.separator");
	
	public void uo(){
		int a = 2;
		System.out.println(" Unary Operator :" + newLine +
						   "---------------------------------------------------------------"+ newLine +
						   " Post Increment = " + a++ + newLine +
				           " Pre  Increment = " + ++a + newLine +
				           " Post Decrement = " + a-- + newLine +
				           " Pre  Decrement = " + --a + newLine +
				           "---------------------------------------------------------------");
	}
}

class ArithmeticalOperator extends UnaryOperator{

	public void ao(){
		int x = 1;
		int y = 2;
		System.out.println(" Arithmetical Operator :" + newLine +
				   "---------------------------------------------------------------"+ newLine +
				   " Addition       = " + (x+y) + newLine +
		           " Subtraction    = " + (x-y) + newLine +
		           " Multiplication = " + (x*y) + newLine +
		           " Division       = " + (x/y) + newLine +
		           " Module         = " + (x%y) + newLine +
		           "---------------------------------------------------------------");
	}
}

class ShiftOperator extends ArithmeticalOperator{

	public void so(){
		int n = 3;
		int m = 4;
		System.out.println(" Shift Operator :" + newLine +
				   "---------------------------------------------------------------"+ newLine +
				   " Left  Shift  = " + (n<<m) + newLine +
		           " Right Shift  = " + (n>>m) + newLine +
		           "i.e n<<m 3*4^4 = 3*16 = 48 "     + newLine+
		           "i.e n>>m 3/4^4 = 3/16 = 0.1875 " + newLine+
		           "---------------------------------------------------------------");
	}
}

class RelationalOperator extends ShiftOperator{
	
	public void ro(){
		int n = 3;
		int m = 4;
		System.out.println(" Relational Operator :" + newLine +
				   "---------------------------------------------------------------"+ newLine +
				   " Greater Than              = " + (n>m) + newLine +
		           " Less Than                 = " + (n<m) + newLine +
		           " Greater Than Equal To     = " + (n>=m) + newLine +
		           " Less Than Equal To        = " + (n<=m) + newLine +
		           "---------------------------------------------------------------");
	}
}

class LogicalOperator extends RelationalOperator{
	
	public void lo(){
		int n = 3;
		int m = 4;
		System.out.println(" Logical Operator :" + newLine +
				   "---------------------------------------------------------------"+ newLine +
				   " And  = " + (n>m && n<m) + newLine +
		           " Or   = " + (n<m || n>m) + newLine +
		           "---------------------------------------------------------------");
	}
}

class TernaryOperator extends LogicalOperator{
	
	public void to(){
		int n = 3;
		int m = 4;
		int min = (n<m)?n:m;
		System.out.println(" Ternary Operator :" + newLine +
				   "---------------------------------------------------------------"+ newLine +
				   " Ternary  = " + min + newLine +
		           "---------------------------------------------------------------");
	}
}
