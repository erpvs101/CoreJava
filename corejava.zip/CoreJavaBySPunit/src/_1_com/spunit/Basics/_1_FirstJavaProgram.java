package _1_com.spunit.Basics;

public class _1_FirstJavaProgram {

	public static void main(String[] args) {

		System.out.println("Hello Worlds");

	}

}
