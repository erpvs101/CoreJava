package _3_com.spunit.Oops;

public class _E_InstanceInitializeBlock {

	public static void main(String[] args) {
		/* Instance Initialize Block is us to initialize the instance data member*/
		Block b = new Block();
		Block b1 = new Block();
		b.show();
		b1.show();
	}
}

class Block{
	int a;
	public void show(){
		System.out.println("Value is :"+a);
	}
	{a=10;}
}