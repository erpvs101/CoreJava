package _3_com.spunit.Oops;

public class _B_Aggregation {

	public static void main(String[] args) {
		/* Aggregation creating reference of class called as Aggregation 
		 * HAS-A Relation
		 * */

		Circle c = new Circle();
		double result = c.area(5);
		System.out.println(result);
	}
}

class Operation {
	int square(int n) {
		return n * n;
	}
}

class Circle {
	Operation op;// aggregation
	double pi = 3.14;

	double area(int radius){  
		   op=new Operation();  
		   int rsquare=op.square(radius);//code reusability (i.e. delegates the method call).  
		   return pi*rsquare;  
		 }
}