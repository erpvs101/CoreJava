package _3_com.spunit.Oops;

public class _A_Inheritance {

	public static void main(String[] args) {
		/* Inheritance : One class acquire the all properties of another class
		 * IS-A Relation 
		 * There are five types of inheritance in java
		 * 1. Single			: A, B extends A
		 * 2. Multilevel		: A, B extends A C extends B
		 * 3. Hierarchical		: A, B extends A C extends A
		 * 4. Multiple (Not used cause showing ambiguity error)
		 * 5. Hybrid
		 * */ 
	}
}
