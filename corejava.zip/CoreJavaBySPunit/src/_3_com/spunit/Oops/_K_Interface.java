package _3_com.spunit.Oops;

public class _K_Interface implements runnable{

	public static void main(String[] args) {
		/*Interface is a blueprint of class. it has static constants and abstract method*/
		_K_Interface obj = new _K_Interface();
		obj.display();
	}

	@Override
	public void display() {
		/*Implementation*/
		System.out.println("In Implementation");
	}
}

interface runnable{
	public void display();
}
