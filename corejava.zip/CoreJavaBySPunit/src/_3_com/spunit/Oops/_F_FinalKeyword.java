package _3_com.spunit.Oops;

public class _F_FinalKeyword {

	final int a = 10;
	
	final void show(){
		//we can't override the final method
	}
	
	// final class we can't reuse the final class 
	
	public static void main(String[] args) {
		/* Final Keyword is used for making variable, method, class as private from other user
		 * if you try to change any one of then we'll get compile time error*/
	}
}
