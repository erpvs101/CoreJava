package _3_com.spunit.Oops;

public class _L_Encapsulation {

	public static void main(String[] args) {
		/* It is a process in which we can wrapping the code into single unit*/
		Student s = new Student();
		s.setName("Punit");
		System.out.println(s.getName());
	}
}

class Student{
	private String name;

	/* Getter & Setter*/	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
