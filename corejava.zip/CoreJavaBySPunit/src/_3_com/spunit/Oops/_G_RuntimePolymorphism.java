package _3_com.spunit.Oops;

public class _G_RuntimePolymorphism {

	public static void main(String[] args) {
		/*Run Time Polymorphism OR Dynamic Method Dispatch 
		 * it is a process in which a call to an overridden method is resolved 
		 * at runtime rather than compile time
		 * */
		A obj = new B();
		obj.display();
	}
}

class A{
	public void display(){
		System.out.println("In A Method");
	}
}

class B extends A{
	public void display(){
		System.out.println("In B Method");
	}
}