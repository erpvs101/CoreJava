package _3_com.spunit.Oops;

public class _H_Binding {

	public static void main(String[] args) {
		/* There two types of binding 
		 * 1. Static	: when type of object is determine at compile time
		 * 2. Dynamic	: when type of object is determine at run time
		 * */ 
		StaticBinding sb = new StaticBinding();
		sb.show();
		
		StaticBinding sb1 = new DynamicBinding();
		sb1.show();
	}
}

class StaticBinding{
	public void show(){
		System.out.println("In Static Binding Method");
	}
}

class DynamicBinding extends StaticBinding{
	public void show(){
		System.out.println("In Static Dynamic Method");
	}
}