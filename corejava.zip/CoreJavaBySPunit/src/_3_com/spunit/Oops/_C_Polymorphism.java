package _3_com.spunit.Oops;

public class _C_Polymorphism  extends MethodOverriding{

	public static void main(String[] args) {
		/* Polymorphism ability of object to take on many forms
		 * Following concept are in polymorphism
		 * 1. Method Overloading : having same method name but different parameter	
		 * 2. Method Overriding	 : child class has same method declare in parent class
		 * */
		
		MethodOverloading methodOverloading = new MethodOverloading();
		methodOverloading.show();
		methodOverloading.show(10);
		
		MethodOverriding methodOverriding = new MethodOverriding();
		methodOverriding.display();
		
	}
}

class MethodOverloading{
	public void show(){
		System.out.println("No Para Method");
	}
	public int show(int a){
		System.out.println("Para Method" + a);
		return a;	
	}
}


class MethodOverriding{
	public void display(){
		System.out.println("In Parent Method");
	}
}