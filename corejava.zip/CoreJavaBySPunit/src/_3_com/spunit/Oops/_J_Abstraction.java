package _3_com.spunit.Oops;

public class _J_Abstraction{

	
	
	public static void main(String[] args) {
		/* Abstraction is a process in which we can hide the implementation of code 
		 * no body present for abstract method & class also should be abstracted
		 * */
		Mn obj = new Mn();
		obj.run();
	}
}

abstract class Xyz{
	abstract void run();						//Abstract method
}

class Mn extends Xyz{
	void run(){
		System.out.println("Implementation");
	}
}
