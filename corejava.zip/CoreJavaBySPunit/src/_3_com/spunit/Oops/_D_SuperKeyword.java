package _3_com.spunit.Oops;

public class _D_SuperKeyword {

	public static void main(String[] args) {
		/* Super Keyword is used for immediate parent class instance variable*/ 

		ChildClass c = new ChildClass();
		c.show();
	}
}

class ParentClass{
	String name = "Vishal";
}

class ChildClass extends ParentClass{
	String name = "Rahul";
	public void show(){
		System.out.println(name);
		System.out.println(super.name);
	}
}
