package _3_com.spunit.Oops;

public class _I_InstanceOf {

	public static void main(String[] args) {
		/*InstanceOf Operator is used to identify whether object is an instance of specific types or not
		 * (i.e. class or subclass or interface)
		 * */ 
		Bcd i = new Bcd();
		System.out.println(i instanceof Abc);
	}
}

class Abc{
}

class Bcd extends Abc{
}
